// CELEBRATE 70 — Journey Page: Full 8-day timeline
import { useState } from "react";
import { MapPin, ChevronRight, ChevronDown } from "lucide-react";
import { TRIP_DAYS, getCurrentDayIndex, type TripDay } from "@/lib/itinerary";
import EventCard from "@/components/EventCard";

function DayHeader({ day, isToday, isPast, isOpen, onToggle }: {
  day: TripDay; isToday: boolean; isPast: boolean; isOpen: boolean; onToggle: () => void;
}) {
  return (
    <button
      className="w-full flex items-center gap-3 p-4 text-left transition-all"
      style={{ background: isToday ? 'oklch(0.28 0.07 155)' : isPast ? 'oklch(0.94 0.03 80)' : 'oklch(1 0 0)' }}
      onClick={onToggle}>
      {/* Day number bubble */}
      <div className="w-10 h-10 rounded-full flex-shrink-0 flex flex-col items-center justify-center"
        style={{ background: isToday ? 'oklch(0.72 0.14 68)' : isPast ? 'oklch(0.88 0.03 80)' : 'oklch(0.94 0.03 80)' }}>
        <span className="text-xs font-bold leading-none" style={{ color: isToday ? 'oklch(0.15 0.04 155)' : 'oklch(0.45 0.04 155)' }}>
          Day
        </span>
        <span className="text-base font-bold leading-none" style={{ color: isToday ? 'oklch(0.15 0.04 155)' : 'oklch(0.28 0.07 155)', fontFamily: "'Playfair Display', serif" }}>
          {day.dayNum}
        </span>
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold" style={{ color: isToday ? 'oklch(0.72 0.14 68)' : 'oklch(0.55 0.04 155)' }}>
            {day.label}
          </span>
          {isToday && (
            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full"
              style={{ background: 'oklch(0.72 0.14 68)', color: 'oklch(0.15 0.04 155)' }}>
              TODAY
            </span>
          )}
          {isPast && !isToday && (
            <span className="text-[10px] font-semibold" style={{ color: 'oklch(0.65 0.04 155)' }}>✓</span>
          )}
        </div>
        <div className="font-bold text-sm leading-snug"
          style={{ color: isToday ? 'oklch(0.97 0.02 85)' : 'oklch(0.20 0.03 155)', fontFamily: "'Playfair Display', serif" }}>
          {day.headline}
        </div>
        <div className="flex items-center gap-1 mt-0.5">
          <MapPin size={11} style={{ color: isToday ? 'oklch(0.80 0.05 85)' : 'oklch(0.65 0.04 155)' }} />
          <span className="text-xs truncate" style={{ color: isToday ? 'oklch(0.80 0.05 85)' : 'oklch(0.55 0.04 155)' }}>
            {day.location}
          </span>
        </div>
      </div>

      <div className="flex-shrink-0">
        {isOpen
          ? <ChevronDown size={18} style={{ color: isToday ? 'oklch(0.72 0.14 68)' : 'oklch(0.55 0.04 155)' }} />
          : <ChevronRight size={18} style={{ color: isToday ? 'oklch(0.72 0.14 68)' : 'oklch(0.55 0.04 155)' }} />}
      </div>
    </button>
  );
}

export default function JourneyPage() {
  const dayIndex = getCurrentDayIndex();
  const [openDays, setOpenDays] = useState<Set<string>>(() => {
    const s = new Set<string>();
    if (dayIndex >= 0 && dayIndex < TRIP_DAYS.length) s.add(TRIP_DAYS[dayIndex].id);
    return s;
  });
  const [expandedEvent, setExpandedEvent] = useState<string | null>(null);

  function toggleDay(id: string) {
    setOpenDays(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="px-4 pt-6 pb-4" style={{ background: 'oklch(0.28 0.07 155)' }}>
        <h1 className="text-2xl font-bold" style={{ color: 'oklch(0.97 0.02 85)', fontFamily: "'Playfair Display', serif" }}>
          Your Journey
        </h1>
        <p className="text-sm mt-1" style={{ color: 'oklch(0.72 0.14 68)' }}>
          17–24 April 2026 · Scotland & Orkney
        </p>
        {/* Progress bar */}
        <div className="mt-3 h-1.5 rounded-full overflow-hidden" style={{ background: 'oklch(0.38 0.08 155)' }}>
          <div className="h-full rounded-full transition-all duration-500"
            style={{
              width: `${Math.max(0, Math.min(100, (dayIndex / TRIP_DAYS.length) * 100))}%`,
              background: 'linear-gradient(to right, oklch(0.72 0.14 68), oklch(0.85 0.12 75))'
            }} />
        </div>
        <div className="flex justify-between mt-1">
          <span className="text-[10px]" style={{ color: 'oklch(0.65 0.05 155)' }}>Sanday</span>
          <span className="text-[10px]" style={{ color: 'oklch(0.65 0.05 155)' }}>Home</span>
        </div>
      </div>

      {/* Days */}
      <div className="divide-y" style={{ borderColor: 'oklch(0.88 0.03 80)' }}>
        {TRIP_DAYS.map((day, idx) => {
          const isToday = idx === dayIndex;
          const isPast = idx < dayIndex;
          const isOpen = openDays.has(day.id);

          return (
            <div key={day.id}>
              <DayHeader
                day={day}
                isToday={isToday}
                isPast={isPast}
                isOpen={isOpen}
                onToggle={() => toggleDay(day.id)}
              />
              {isOpen && (
                <div className="px-4 py-3 timeline-spine pl-14"
                  style={{ background: isToday ? 'oklch(0.28 0.07 155 / 0.04)' : 'oklch(0.97 0.02 85 / 0.5)' }}>
                  <div className="space-y-3">
                    {day.events.map((event, eIdx) => (
                      <EventCard
                        key={event.id}
                        event={event}
                        isFirst={eIdx === 0}
                        isLast={eIdx === day.events.length - 1}
                        isExpanded={expandedEvent === event.id}
                        onToggle={() => setExpandedEvent(expandedEvent === event.id ? null : event.id)}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div className="p-4 text-center">
        <p className="text-xs" style={{ color: 'oklch(0.65 0.04 155)' }}>
          Clive & Jane Struver · Vehicle SW16YOP
        </p>
      </div>
    </div>
  );
}
